let modal = document.getElementById('login');

window.onclick = function(event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
}



