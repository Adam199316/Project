let cars = {
    data: [
        {
            productName: "Skoda Rapid",
            url: "rapid.html",
            category: "Osobniauta",
            price: "89000",
            image: "images/rapid.png",
        },
        {
            productName: "Peugot 206",
            url: "#",
            category: "Osobniauta",
            price: "50000",
            image: "images/peugot.png",
        },
        {
            productName: "Ford Transit",
            url: "#",
            category: "dodavky",
            price: "65000",
            image: "images/transit.png",
        },
        {
            productName: "VW Transporter",
            url: "transporter.html",
            category: "dodavky",
            price: "63000",
            image: "images/transporter.png",
        },
        {
            productName: "Mitshubishi ASX",
            url: "#",
            category: "SUV",
            price: "200000",
            image: "images/asx.png",
        },
        {
            productName: "Kia Sorento",
            url: "#",
            category: "SUV",
            price: "260000",
            image: "images/sorento.png",
        },
        {
            productName: "Audi A4",
            url: "#",
            category: "Kombi",
            price: "100000",
            image: "images/audi.png",
        },
        {
            productName: "Skoda Octavia",
            url: "#",
            category: "Kombi",
            price: "80000",
            image: "images/octavia.png",
        },
    ],
};

for (let i of cars.data) {
    let card = document.createElement("div");
    card.classList.add("card", i.category, "hide");

    let imgContainer = document.createElement("div");
    imgContainer.classList.add("image-container");

    let image = document.createElement("img");
    image.setAttribute("src", i.image);
    imgContainer.appendChild(image);
    card.appendChild(imgContainer);

    let container = document.createElement("div");
    container.classList.add("container");

    let name = document.createElement("h5");
    name.classList.add("product-name");

    if (i.url) {
        let link = document.createElement("a");
        link.setAttribute("href", i.url);
        link.setAttribute("target", "_blank");
        link.innerText = i.productName.toUpperCase();
        name.appendChild(link);
    } else {
        name.innerText = i.productName.toUpperCase();
    }

    container.appendChild(name);

    let price = document.createElement("h6");
    price.innerText = i.price + " Cz";
    container.appendChild(price);

    card.appendChild(container);

    document.getElementById("cars").appendChild(card);
}

function filterCars(value) {
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
        if (value.toUpperCase() === button.innerText.toUpperCase()) {
            button.classList.add("active");
        } else {
            button.classList.remove("active");
        }
    });
    let elements = document.querySelectorAll(".card");
    elements.forEach((element) => {
        if (value === "all") {
            element.classList.remove("hide");
        } else {
            if (element.classList.contains(value)) {
                element.classList.remove("hide");
            } else {
                element.classList.add("hide");
            }
        }
    });
}

document.getElementById("search").addEventListener("click", () => {
    let searchInput = document.getElementById("search-input").value;
    let elements = document.querySelectorAll(".product-name");
    let cards = document.querySelectorAll(".card");
    elements.forEach((element, index) => {
        if (element.innerText.includes(searchInput.toUpperCase())) {
            cards[index].classList.remove("hide");
        } else {
            cards[index].classList.add("hide");
        }
    });
});

window.onload = () => {
    filterCars("all");
};
